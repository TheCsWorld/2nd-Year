package telecoms2;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

//broker acts as this
import tcdIO.Terminal;
import telecoms2.OpenFlowPacketType.ofp_type;

public class Switch2 extends Node implements Runnable {
	final static int RECV_PORT = 11111;
	final static int SEND_PORT = 11123;
	static final String DEFAULT_DST_NODE = "localhost";
	
	static final int PACKETSIZE = 65536;
	static final int Controller_DESC_PORT = 11115;
	InetSocketAddress dstAddress;

	static Terminal terminal;

	static int flag = -1;
	static String nextRouter;
	static Dictionary<String, String> routeTable = new Hashtable<String, String>(); 
	
	/*
	 * Switch Class
	 */
	Switch2(Terminal terminal, int port) {
		try {
			this.terminal= terminal;
			dstAddress = new InetSocketAddress(DEFAULT_DST_NODE, Controller_DESC_PORT);
			socket= new DatagramSocket(port);
			listener.go();
			
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public synchronized void onReceipt(DatagramPacket packet) {

		byte[] buffer;
		try {
			ParsePacket(packet);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}



	private void ParsePacket(DatagramPacket packet) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		ObjectInputStream ostreamIn;
		ByteArrayInputStream bstreamIn;
		
		byte[] buffer;
		try {
		// create buffer for data, packet and socket
		buffer= new byte[PACKETSIZE+3];
		// extract data from packet
		buffer= packet.getData();
		bstreamIn= new ByteArrayInputStream(buffer);
		ostreamIn= new ObjectInputStream(bstreamIn);
			
		 String[] messages = new String[5];
		 
		 messages[0] = ostreamIn.readUTF();
		 ofp_type messageType = (ofp_type) ostreamIn.readObject();
		 
			 
		int endIndex = messages[0].lastIndexOf("_");
		
		String content = null;
		// here we need to know message type
		switch(messageType) {
			case OFPT_REQUESTFORWARD:
				content = "Forward Packet";
				terminal.println("Switch2 received  " +content+" message from " + messages[0].substring(0, endIndex));
				flag = 10;
				break;
			case OFPT_HELLO:
				content = "Hello";
				terminal.println("Switch2 received  " +content+" message from " + messages[0].substring(0, endIndex));
				break;
			case OFPT_FEATURES_REQUEST:
				content = "Feature Request";
				terminal.println("Switch2 received  " +content+" message from " + messages[0].substring(0, endIndex));
				flag = 5;
				break;
			case OFPT_PACKET_IN:
				content = "PacketIn";
				terminal.println("Switch2 received  " +content+" message from " + messages[0].substring(0, endIndex));
				break;
			case OFPT_FLOW_MOD:
				content = "Flow Mod";
				terminal.println("Switch2 received  " +content+" message from " + messages[0].substring(0, endIndex));
				messages[2] = ostreamIn.readUTF();
				messages[3] = ostreamIn.readUTF();
				nextRouter = ostreamIn.readUTF();
				
				routeTable.put(messages[2].split(":")[0],messages[2].split(":")[1]);
				terminal.println("Switch2 added path " +messages[2]+ " to route table");
				routeTable.put(messages[3].split(":")[0],messages[3].split(":")[1]);
				terminal.println("Switch2 added path " +messages[3]+ " to route table");
				flag = 14;
				break;
			default:
				break;
			
		}
		

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("controller send hello message error : " + e.getMessage());
			e.printStackTrace();
		}
			
	}
	
	private void forwardPacketIn(String nextRouter) {
		// TODO Auto-generated method stub
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;
		
		DatagramPacket packet= null;
		terminal.println("Switch2 forwarding packet to the next Router");
		
		bstream= new ByteArrayOutputStream();
		try {
			ostream= new ObjectOutputStream(bstream);
			Date date= new Date();
			long time = date.getTime();
			Timestamp ts = new Timestamp(time);
			
			ostream.writeUTF("R2-"+RECV_PORT+"_"+ts);
			ostream.writeObject(OpenFlowPacketType.ofp_type.OFPT_REQUESTFORWARD);
			
			ostream.flush();
			buffer= bstream.toByteArray();

			// create packet addressed to destination receive port number
			int startIndex = nextRouter.indexOf(":")+1;
	    	int endIndex = nextRouter.lastIndexOf(",");	    	
			int Next_Router_PORT = Integer.parseInt(nextRouter.substring(startIndex,endIndex));
			
		    dstAddress = new InetSocketAddress(DEFAULT_DST_NODE, Next_Router_PORT);
			packet= new DatagramPacket(buffer, buffer.length, dstAddress);

			// create socket and send packet
			socket= new DatagramSocket();
			socket.send(packet);
			this.notify();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void sendPacketIn() {
		// TODO Auto-generated method stub
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;
		
		DatagramPacket packet= null;
		terminal.println("Switch2 sending packet to the Controller");
		
		bstream= new ByteArrayOutputStream();
		try {
			ostream= new ObjectOutputStream(bstream);
			Date date= new Date();
			long time = date.getTime();
			Timestamp ts = new Timestamp(time);
			
			ostream.writeUTF("R2-"+RECV_PORT+"_"+ts);
			ostream.writeObject(OpenFlowPacketType.ofp_type.OFPT_PACKET_IN);
			ostream.flush();
			buffer= bstream.toByteArray();

			// create packet addressed to destination
			
			packet= new DatagramPacket(buffer, buffer.length, dstAddress);

			// create socket and send packet
			socket= new DatagramSocket();
			socket.send(packet);
			this.notify();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	private void sendFeatureReply() throws IOException {
		// TODO Auto-generated method stub
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;

		DatagramPacket packet= null;
		terminal.println("Switch2 sent Feature Reply Message to the Controller");
		
		bstream= new ByteArrayOutputStream();
		ostream= new ObjectOutputStream(bstream);
		
		Date date= new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		
		ostream.writeUTF("R2-"+RECV_PORT+"_"+ts);
		ostream.writeObject(OpenFlowPacketType.ofp_type.OFPT_FEATURES_REPLY);
		ostream.flush();
		buffer= bstream.toByteArray();

		
		packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);


		this.notify();
	}

	public synchronized void start() throws Exception {
		System.out.println("send message thread : ");
		ContactController();
		while(true) {
			switch(flag) {
				case 5:
					sendFeatureReply();
					flag = -1;
					break;
				case 10:
					sendPacketIn();
					flag = -1;	
					break;
				case 14:
					forwardPacketIn(nextRouter);
					flag = -1;		
					break;
				default:
					break;
			}
			
			Thread.sleep(1000);
		}
		
	}

	/*
	 * 
	 */
	public static void main(String[] args) {
		try {					
			Terminal terminal= new Terminal("Switch2");
		
			// start thread to wait for reply
			new Thread(new Switch2(terminal,RECV_PORT)).start();
			// start to contact controller
			new Switch2(terminal,SEND_PORT).start();
			
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}

	private void ContactController() throws IOException {
		// TODO Auto-generated method stub
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;

		DatagramPacket packet= null;
		terminal.println("Switch2 sent Hello Message");
		
		bstream= new ByteArrayOutputStream();
		ostream= new ObjectOutputStream(bstream);
		
		Date date= new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		
		ostream.writeUTF("R1-"+RECV_PORT+"_"+ts);
		ostream.writeObject(OpenFlowPacketType.ofp_type.OFPT_HELLO);
		ostream.flush();
		buffer= bstream.toByteArray();

		// create packet addressed to destination
		InetSocketAddress dstAddress= new InetSocketAddress(DEFAULT_DST_NODE, Controller_DESC_PORT);
		packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);

		this.notify();
	}

	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		try {
			while(true) {
				System.out.println("Switch2 wait...");
				this.wait();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Switch2 wait error : " + e.getMessage());
			e.printStackTrace();
		}
		
	}

	
}
