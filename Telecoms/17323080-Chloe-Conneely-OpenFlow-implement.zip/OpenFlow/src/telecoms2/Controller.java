package telecoms2;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


//broker acts as this
import tcdIO.Terminal;
import telecoms2.OpenFlowPacketType.ofp_type;

public class Controller extends Node implements Runnable {
	final static int RECV_PORT = 11115;					//receive from router
	final static int SEND_PORT = 11116;					//send to router
	static final String DEFAULT_DST_NODE = "localhost";
	
	static final int PACKETSIZE = 65536;
	
    static int Notify_DESC_PORT = 0;		//router port
	static String Controller = null;		//type in packet
	static String Source = null;			//type in packet

	static int flag = -1;					//
	static int routerPort;					//router port
	static Terminal terminal;
	static Dictionary<String, String> routeTable = new Hashtable<String, String>(); 
	
	/*
	 * Controller Class
	 */
	Controller(Terminal terminal, int port) {
		try {
			this.terminal= terminal;
			socket= new DatagramSocket(port);
			listener.go();
			
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public synchronized void onReceipt(DatagramPacket packet) {

		byte[] buffer;

		terminal.println("Controller trying to receive");
		try {
			ParsePacket(packet);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private void ParsePacket(DatagramPacket packet) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		ObjectInputStream ostreamIn;
		ByteArrayInputStream bstreamIn;
		
		byte[] buffer;
		try {
		// create buffer for data, packet and socket
		buffer= new byte[PACKETSIZE+3];
		// extract data from packet
		buffer= packet.getData();
		bstreamIn= new ByteArrayInputStream(buffer);
		ostreamIn= new ObjectInputStream(bstreamIn);
			
		 String[] messages = new String[3];
		 messages[0] = ostreamIn.readUTF();
		 OpenFlowPacketType.ofp_type messageType = (ofp_type) ostreamIn.readObject();
			 
		int startIndex = messages[0].indexOf("-");
		int endIndex = messages[0].lastIndexOf("_");
		
		String content = null;
		// here we need to know message type
		switch(messageType) {
			case OFPT_HELLO:
				content = "Hello";
				Date date= new Date();
				long time = date.getTime();
				Timestamp ts = new Timestamp(time);
				Controller = "C-"+RECV_PORT +"_"+ts;
				Notify_DESC_PORT = Integer.parseInt(messages[0].substring(startIndex+1,endIndex));
				Source = messages[0].substring(0, endIndex);
				flag = 0;
				break;
			case OFPT_FEATURES_REPLY:
				content = "Feature Reply";
				break;
			case OFPT_PACKET_IN:
				content = "PacketIn";
				Source = messages[0].substring(0, endIndex);
			    routerPort = Integer.parseInt(messages[0].substring(startIndex+1,endIndex));
				flag = 10;
				break;
			default:
				break;
			
		}
		
		terminal.println("Controller received "+content+" message from " + messages[0].substring(0, endIndex));

		

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("controller send hello message error : " + e.getMessage());
			e.printStackTrace();
		}
	}

	private void sendFlowTable(int routerPort) {
		// TODO Auto-generated method stub
		ByteArrayOutputStream bstream= new ByteArrayOutputStream();
		ObjectOutputStream ostream;
		try {
			ostream = new ObjectOutputStream(bstream);
			
			String[] routers = routeTable.get("router").split(";");
			String DescPath = null;

			int counter = 0;
			for (String r: routers) {           
			    //Do your stuff here
			    if(r.indexOf(Source.substring(0, Source.indexOf("-")))>=0) {
			    	int startIndex = r.indexOf(":")+1;
			    	int endIndex = r.lastIndexOf("}");
			    	DescPath = r.substring(startIndex,endIndex);
			    	break;
			    }
			    counter++;
			}
			ostream.writeUTF(Controller);
			
			// send router flow table with R1 Path and Next R2 Receive Port number
			ostream.writeObject(OpenFlowPacketType.ofp_type.OFPT_FLOW_MOD);
			ostream.writeUTF(routeTable.get("dest").substring(routeTable.get("dest").indexOf("{")+1, routeTable.get("dest").indexOf(":")) + ":" + DescPath);
			
			
			String srcPath = DescPath.split(",")[1]+","+DescPath.split(",")[0];
			ostream.writeUTF(routeTable.get("src").substring(routeTable.get("src").indexOf("{")+1, routeTable.get("src").indexOf(":")) + ":" + srcPath);
			// add next router information
			String destPort = counter+1==routeTable.size() ? routeTable.get("dest") :routers[counter+1];
			ostream.writeUTF(destPort);
			
			ostream.flush();
			byte[] buffer= bstream.toByteArray();
			
			// create packet addressed to destination
			InetSocketAddress dstAddress= new InetSocketAddress(DEFAULT_DST_NODE,routerPort);
			DatagramPacket packet= new DatagramPacket(buffer, buffer.length, dstAddress);

			// create socket and send packet
			socket= new DatagramSocket();
			socket.send(packet);
			
			
			this.notify();
			terminal.println("Controller sent Flow Mod Message to " + Source);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void sendFeatureRequest(String Source, String Controller, int notify_DESC_PORT) throws IOException {
		// TODO Auto-generated method stub
		ByteArrayOutputStream bstream= new ByteArrayOutputStream();
		ObjectOutputStream ostream= new ObjectOutputStream(bstream);
		
		ostream.writeUTF(Controller);
		ostream.writeObject(OpenFlowPacketType.ofp_type.OFPT_FEATURES_REQUEST);
		
		ostream.flush();
		byte[] buffer= bstream.toByteArray();

		
		// create packet addressed to destination
		InetSocketAddress dstAddress= new InetSocketAddress(DEFAULT_DST_NODE, notify_DESC_PORT);
		DatagramPacket packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);
		
		
		this.notify();
		terminal.println("Controller sent Feature Request Message to " + Source);
		
		
	}

	private void sendHelloMessage(String Controller,int notify_DESC_PORT) throws IOException {

		ByteArrayOutputStream bstream= new ByteArrayOutputStream();
		ObjectOutputStream ostream= new ObjectOutputStream(bstream);
		ostream.writeUTF(Controller);
		ostream.writeObject(OpenFlowPacketType.ofp_type.OFPT_HELLO);
		ostream.flush();
		byte[] buffer= bstream.toByteArray();

		
		// create packet addressed to destination
		InetSocketAddress dstAddress= new InetSocketAddress(DEFAULT_DST_NODE, notify_DESC_PORT);
		DatagramPacket packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);

		this.notify();
		terminal.println("Controller sent Hello Message to " + Source);
		flag = -1;
		sendFeatureRequest(Source,Controller,Notify_DESC_PORT);
	}

	public synchronized void start() throws Exception {
		System.out.println("send message thread : ");
		while(true) {
			switch(flag) {
				case 0:
					sendHelloMessage(Controller,Notify_DESC_PORT);
					flag = -1;
					break;
				case 10:
					sendFlowTable(routerPort);
					flag= -1;
				default:
					break;
			}
			Thread.sleep(1000);
		}
		
	}

	/*
	 * 
	 */
	public static void main(String[] args) {
		try {					
			Terminal terminal= new Terminal("Controller");
			InitPreConfiguration();
		
			new Thread(new Controller(terminal,RECV_PORT)).start();
			new Controller(terminal,SEND_PORT).start();
			
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}

	private static void InitPreConfiguration() {
		// TODO Auto-generated method stub
		routeTable.put("dest", "{E4:11102,11103}");
		routeTable.put("src", "{E1:11100,11101}");
		routeTable.put("router", "{R1:11113,11114};{R2:11111,11123};{R4:11143,11112}");
	}

	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		try {
			terminal.println("Waiting for connections from routers ...");
			while(true) {
				System.out.println("Controller wait...");
				this.wait();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Controller wait error : " + e.getMessage());
			e.printStackTrace();
		}
		
	}

	

}
