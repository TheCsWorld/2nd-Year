package telecoms2;

import java.net.DatagramSocket;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.sql.Timestamp;
import java.util.Date;


import tcdIO.*;
import telecoms2.Node;


public class Destination extends Node implements Runnable{
	
	static final int DEST_PORT = 11102; 				//router4 port
	static final int DEFAULT_SRC_SEND_PORT = 11102; 	//send message to router
	static final int DEFAULT_SRC_REC_PORT = 11103; 		//receive from router
	static final String DEFAULT_DST_NODE = "localhost";
	static final int PACKETSIZE = 65536;	//size of packet
	

	Terminal terminal;
	InetSocketAddress dstAddress;	//address to construct packet to send
	
	Destination(Terminal terminal, String dstHost, int dstPort, int srcPort) {
		try {
			this.terminal= terminal;
			dstAddress= new InetSocketAddress(dstHost, dstPort);
			socket= new DatagramSocket(srcPort);
			listener.go();
			
			
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public synchronized void onReceipt(DatagramPacket packet) {
		byte[] buffer;
		
		try {
			// attempt to receive packet
			terminal.println("Destination trying to receive");
			ObjectInputStream ostreamIn;
			ByteArrayInputStream bstreamIn;
			
			// create buffer for data, packet and socket
			buffer= new byte[PACKETSIZE+3];
			// extract data from packet
			buffer= packet.getData();
			bstreamIn= new ByteArrayInputStream(buffer);
			ostreamIn= new ObjectInputStream(bstreamIn);
				
			String[] messages = new String[3];
			messages[0] = ostreamIn.readUTF();
			
			int endIndex = messages[0].lastIndexOf("_");

			terminal.println("Destination received packet message from " + messages[0].substring(0, endIndex));	

		}
		catch(Exception e) {
			System.out.println("dest receive error " + e.getMessage());
		}
	}
	
	public static void main(String[] args) {
		try {					
			Terminal terminal= new Terminal("Destination");	
			(new Thread(new Destination(terminal, DEFAULT_DST_NODE, DEST_PORT, DEFAULT_SRC_REC_PORT))).start();
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}

	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Hello from destination thread!");
			while(true) {
				this.wait();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

}
