package telecoms2;

import java.net.DatagramSocket;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.sql.Timestamp;
import java.util.Date;

import tcdIO.*;
import telecoms2.Node;


public class Source extends Node implements Runnable{
	static final int DEST_PORT = 11113; 		//router1 port
	static final int DEFAULT_SRC_SEND_PORT = 11100; 	//send message to router
	static final int DEFAULT_SRC_REC_PORT = 11101; 	//receive from router
	static final String DEFAULT_DST_NODE = "localhost";
	
	public static final int PACKETSIZE = 65536;
	Terminal terminal;
	InetSocketAddress dstAddress;			//address to construct packet to send
	
	/**
	 * Constructor
	 * 	 
	 * Attempts to create socket at given port and create an InetSocketAddress for the destinations
	 */
	Source(Terminal terminal, String dstHost, int dstPort, int srcPort) {
		try {
			this.terminal= terminal;
			dstAddress= new InetSocketAddress(dstHost, dstPort);
			socket= new DatagramSocket(srcPort);
			listener.go();
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}
	
	/**
	 * Sender Method
	 * 
	 */
	public synchronized void sendPacketIn() throws Exception {
		
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;
		
		DatagramPacket packet= null;
		terminal.println("Source sending packet");
		
		bstream= new ByteArrayOutputStream();
		ostream= new ObjectOutputStream(bstream);
		
		Date date= new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		
		ostream.writeUTF("Source" + DEFAULT_SRC_REC_PORT+"_"+ts);
		ostream.writeObject(OpenFlowPacketType.ofp_type.OFPT_PACKET_IN);
		ostream.flush();
		buffer= bstream.toByteArray();

		// create packet addressed to destination
		packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);

	}
	
	public synchronized void start() throws Exception {
		System.out.println("send message thread : ");
		sendPacketIn();
		Thread.sleep(1000);
	}
	
	/**
	 * Test method
	 * 
	 * Sends a packet to a given address
	 */
	public static void main(String[] args) {
		try {					
			Terminal terminal= new Terminal("Source");	
			(new Thread(new Source(terminal, DEFAULT_DST_NODE, DEST_PORT, DEFAULT_SRC_REC_PORT))).start();//receive
			(new Source(terminal, DEFAULT_DST_NODE, DEST_PORT, DEFAULT_SRC_SEND_PORT)).start();	//send 

		} catch(java.lang.Exception e) {e.printStackTrace();}
	}
	

	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Hello from source thread!");
			while(true) {
				System.out.print("source wait..");
				this.wait();
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onReceipt(DatagramPacket packet) {
		// TODO Auto-generated method stub
		
	}

}
