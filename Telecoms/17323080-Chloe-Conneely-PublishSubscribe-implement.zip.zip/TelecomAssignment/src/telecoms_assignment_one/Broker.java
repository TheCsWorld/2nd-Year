package telecoms_assignment_one;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

//broker acts as this
import tcdIO.Terminal;

public class Broker extends Node implements Runnable {
	final static int RECV_PORT = 11222;		//port where broker receives
	final static int SEND_PORT = 12345;		//port where broker sends
	static final String DEFAULT_DST_NODE = "localhost";
	
	static int SEQ_NUMBER = 0;				//seq number
	
	static int DESC_PORT = 0;			//port to where broker sends messages to sub
	static Boolean PUB_NOTIFY = false;	//notify publisher
	static String[] fwdMessages ;		//string to forward messages from pub to sub
	static String[] notifyMessages;		//string for notifications
	
	static Boolean ACK_RETRAN = false;
	static String[] ackMessages;
	
	static List<String> publisherAddressList = new ArrayList<>();	//list of publishers
	
	static final int PACKETSIZE = 65536;
	

	static Terminal terminal;
	static Dictionary<String, String> topicList = new Hashtable<String, String>(); //list of topics
	/*
	 * Broker Class
	 */
	Broker(Terminal terminal, int port) {
		try {
			this.terminal= terminal;
			socket= new DatagramSocket(port);
			listener.go();
			
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public synchronized void onReceipt(DatagramPacket packet) {

		byte[] buffer;
		
		try {
			// attempt to receive packet
			terminal.println("Broker trying to receive");
			ParsePacket(packet);
			
			
		}
		catch(Exception e) {e.printStackTrace();}
	}

	
	private void ParsePacket(DatagramPacket packet) {
		ObjectInputStream ostreamIn;
		ByteArrayInputStream bstreamIn;
		
		byte[] buffer;
		
		try {

			
			// create buffer for data, packet and socket
			buffer= new byte[PACKETSIZE+3];
			// extract data from packet
			buffer= packet.getData();
			bstreamIn= new ByteArrayInputStream(buffer);
			ostreamIn= new ObjectInputStream(bstreamIn);

			
			 String[] messages = new String[3];
			 messages[0] = ostreamIn.readUTF();
			 messages[1] = ostreamIn.readUTF();
			 
			 if(messages[0].indexOf("P")==0) {
				 // for publisher, it stores topic and message
				 publisherAddressList.add(messages[0]);
				 
				 int endIndex = messages[0].lastIndexOf("_"); //timestamp
				 messages[2] = ostreamIn.readUTF();
				 terminal.println("Broker received packet from : " + messages[0].substring(0, endIndex) + " topic: " + messages[1] + " message: " + messages[2]);
				 CheckTopicList(messages);
				 
				 PUB_NOTIFY = true;
				 notifyMessages = messages;
			 } else {
				 int endIndex = messages[0].lastIndexOf("_");
				 terminal.println("Broker received packet from : " + messages[0].substring(0, endIndex) + " topic: " + messages[1]);
				 AddTopicList(messages);
			 }
	         
			
		}catch(Exception e) {
			System.out.println(" parse package exception " + e.getMessage());
			e.printStackTrace();
		}

	}

	private void AddTopicList(String[] messages) {
		// TODO Auto-generated method stub
		String sender = messages[0];
		String topic = messages[1];
		if(topic.indexOf("unsubscribe")>=0) {
			// if subscriber un subscribe from topics, we could remove from list
			String removalTopic = topic.substring(topic.indexOf("-")+1);
			for(Map.Entry list:((Hashtable<String, String>) topicList).entrySet()){  
				   String senderInList = list.getKey().toString();
				   String topicInList = list.getValue().toString();
				   if(topicInList.equals(removalTopic)) {
					   topicList.remove(senderInList);
					   terminal.println("Remove topic : "+ removalTopic +" from list sucessfully ");
					   break;
				   }
			 } 
			
		} else {
			// here to avoid duplicated key
			topicList.put(sender,topic);
		}
		
	}

	private void sendNotifyPublisher(String messages[], String content) {
		// TODO Auto-generated method stub
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;
		try {
		DatagramPacket packet= null;
		int startIndex = messages[0].indexOf("-");
		int endIndex = messages[0].lastIndexOf("_");
		
		terminal.println("Broker " + content +" Publisher : " + messages[0].substring(0, endIndex));
		
		bstream= new ByteArrayOutputStream();
		ostream= new ObjectOutputStream(bstream);
		
		ostream.writeUTF(content);
		ostream.flush();
		buffer= bstream.toByteArray();
		
		
		int Notify_DESC_PORT = Integer.parseInt(messages[0].substring(startIndex+1,endIndex));
		
		// create packet addressed to destination
		InetSocketAddress dstAddress= new InetSocketAddress(DEFAULT_DST_NODE, Notify_DESC_PORT);
		packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);
		this.notify();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("send publisher notification message error : " + e.getMessage());
			e.printStackTrace();
		}
	}

	private void CheckTopicList(String[] messages) {
		// TODO Auto-generated method stub
		String topic = messages[1];
		
		
		
		if(((Hashtable<String, String>) topicList).containsValue(topic))
			{
	            // search list , if found , we need to forward to subscriber
				 for(Map.Entry list:((Hashtable<String, String>) topicList).entrySet()){  
					   String sender = list.getKey().toString();
					   String topicInList = list.getValue().toString();
					   if(topicInList.equals(topic)) {
						   // we need to remove time stamp
						   int startIndex = sender.indexOf("-");
						   int endIndex = sender.lastIndexOf("_");
						   DESC_PORT = Integer.parseInt(sender.substring(startIndex+1,endIndex));
						   fwdMessages = messages;
						   break;
					   }
				 } 
			}
		
		
	}

	private synchronized void SendMessage(int descPort,String[] messages) throws InterruptedException {
		// TODO Auto-generated method stub
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;
		try {
		DatagramPacket packet= null;
		terminal.println("Broker forwarding message");
		
		bstream= new ByteArrayOutputStream();
		ostream= new ObjectOutputStream(bstream);
		
		ostream.writeUTF(messages[1]);
		ostream.writeUTF(SEQ_NUMBER + "  " + messages[2]);
		ostream.flush();
		buffer= bstream.toByteArray();

		// create packet addressed to destination
		InetSocketAddress dstAddress= new InetSocketAddress(DEFAULT_DST_NODE, descPort);
		packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);
		SEQ_NUMBER ++;
		DESC_PORT = 0;
		this.notify();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("send message error : " + e.getMessage());
			e.printStackTrace();
		}
		
	}

	public synchronized void start() throws Exception {
		System.out.println("send message thread : ");
		while(true) {
			
			if(DESC_PORT!=0) {
				SendMessage(DESC_PORT,fwdMessages);
			} else if (PUB_NOTIFY) {
				sendNotifyPublisher(notifyMessages,"notify");
				PUB_NOTIFY = false;
			} else if(ACK_RETRAN) {
				sendNotifyPublisher(ackMessages,"ack");
				ACK_RETRAN = false;
			}
			// every one second check if need to forward/notify publisher message
			Thread.sleep(1000);
		}
		
	}

	/*
	 * 
	 */
	public static void main(String[] args) {
		try {					
			Terminal terminal= new Terminal("Broker");
		
			startTimerTask();
			new Thread(new Broker(terminal,RECV_PORT)).start();	//receive
			new Broker(terminal,SEND_PORT).start();				//send 

			
		    
			
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}

	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		try {
			terminal.println("Waiting for contact");
			while(true) {
				System.out.println("broker wait...");
				this.wait();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("broker wait error : " + e.getMessage());
			e.printStackTrace();
		}
		
	}

	private static void startTimerTask() {
		TimerTask repeatedTask = new TimerTask() {
	        public void run() {
            System.out.println("Task performed on: " + new Date() + "n" +
	              "Thread's name: " + Thread.currentThread().getName());

	        		Date date= new Date();
	        		long time = date.getTime();
	        		Timestamp currentTS = new Timestamp(time);
	        		
	        		for (Iterator<String> iterator = publisherAddressList.iterator(); iterator.hasNext(); ) {
	        			 // we need to remove time stamp
	        			   String item = iterator.next();
	     				   int startIndex = item.indexOf("_");
	     				   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	     				   try {
	     					   Date parsedDate = dateFormat.parse(item.substring(startIndex+1));
	     					   Timestamp senderTS = new java.sql.Timestamp(parsedDate.getTime());
	     					   System.out.println("current " + currentTS + " send " + senderTS);
	     					   long milliseconds = currentTS.getTime() - senderTS.getTime();
	     					   int elapsedTime = (int) milliseconds / 1000;
	     					   if(elapsedTime>60) {
	     						   terminal.println("publisher packet has lost, we need to retransmit");
	     						   ACK_RETRAN = true;
	     						   
	     						   String[] messages = new String[1];
	     						   messages[0] = item;
	     						   ackMessages = messages;
	     						   iterator.remove();
	     					   }
	     					   
							} catch (ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
	     				   
	        		}
	        		
	        		
	        }
	    };
		Timer timer = new Timer("Timer");
		long delay  = 1000L;
	    long period = 10000L;
	    timer.scheduleAtFixedRate(repeatedTask, delay, period);
		
	}

}
