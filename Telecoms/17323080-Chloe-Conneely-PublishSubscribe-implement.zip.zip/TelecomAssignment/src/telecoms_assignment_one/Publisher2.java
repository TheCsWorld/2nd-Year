package telecoms_assignment_one;

import java.net.DatagramSocket;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.sql.Timestamp;
import java.util.Date;

//publisher and subscriber act as this
import tcdIO.*;

/**
 *
 *  Publisher class
 * 
 * An instance accepts user input 
 *
 */
public class Publisher2 extends Node implements Runnable {
	static final int DEST_PORT = 11222;
	static final int DEFAULT_SRC_SEND_PORT = 21221;
	static final int DEFAULT_SRC_REC_PORT = 21321;
	static final String DEFAULT_DST_NODE = "localhost";
	
	static final int TYPE_PUB = 1;
	static final int PACKETSIZE = 65536;
	
	static Boolean Notify_From_Broker = true;
	
	Terminal terminal;
	InetSocketAddress dstAddress;
	
	/**
	 * Constructor
	 * 	 
	 * Attempts to create socket at given port and create an InetSocketAddress for the destinations
	 */
	Publisher2(Terminal terminal, String dstHost, int dstPort, int srcPort) {
		try {
			this.terminal= terminal;
			dstAddress= new InetSocketAddress(dstHost, dstPort);
			socket= new DatagramSocket(srcPort);
			listener.go();
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	
	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public synchronized void onReceipt(DatagramPacket packet) {
		ObjectInputStream ostreamIn;
		ByteArrayInputStream bstreamIn;
		
		byte[] buffer;
		
		try {

			
			// create buffer for data, packet and socket
			buffer= new byte[PACKETSIZE+2];
			// extract data from packet
			buffer= packet.getData();
			bstreamIn= new ByteArrayInputStream(buffer);
			ostreamIn= new ObjectInputStream(bstreamIn);

			String[] messages = new String[2];
			 messages[0] = ostreamIn.readUTF();
		     System.out.println(" publisher2 receive notification :" + messages[0]);
		     if(messages[0].equals("ack")) {
		    	terminal.println(" publisher2 packet is lost, need to re input last package message");
		     }
			 if(messages[0].equals("notify")) {
				 Notify_From_Broker = true;
			 } 
			
		}catch(Exception e) {
			System.out.println(" parse package exception " + e.getMessage());
			e.printStackTrace();
		}
		
	}

	
	/**
	 * Sender Method
	 * 
	 */
	public synchronized void sendMessage() throws Exception {
		
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;
		
		DatagramPacket packet= null;
		terminal.println("Publisher2 sending packet");
		
		bstream= new ByteArrayOutputStream();
		ostream= new ObjectOutputStream(bstream);
		
		String inputTopic = (terminal.readString("Topic to send: "));
		String inputMessage = (terminal.readString("Message to send: "));
		
		Date date= new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		
		ostream.writeUTF("P-" + DEFAULT_SRC_REC_PORT+"_"+ts);
		
		ostream.writeUTF(inputTopic);
		ostream.writeUTF(inputMessage);
		ostream.flush();
		buffer= bstream.toByteArray();

		// create packet addressed to destination
		packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);

	}
	
	public synchronized void start() throws Exception {
		System.out.println("send message thread : ");
		while(true) {
			System.out.println(" check notify broker : " + Notify_From_Broker);
			if(Notify_From_Broker) {
				sendMessage();
				Notify_From_Broker = false;
			} 
			
			Thread.sleep(1000);
		}
	}


	/**
	 * Test method
	 * 
	 * Sends a packet to a given address
	 */
	public static void main(String[] args) {
		try {					
			Terminal terminal= new Terminal("Publisher2");	
			(new Thread(new Publisher2(terminal, DEFAULT_DST_NODE, DEST_PORT, DEFAULT_SRC_REC_PORT))).start();
			(new Publisher2(terminal, DEFAULT_DST_NODE, DEST_PORT, DEFAULT_SRC_SEND_PORT)).start();

		} catch(java.lang.Exception e) {e.printStackTrace();}
	}


	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Hello from a publisher2 receive thread!");
			while(true) {
				System.out.print("publisher2 wait..");
				this.wait();
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
