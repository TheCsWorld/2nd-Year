package telecoms_assignment_one;

import java.net.DatagramSocket;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.sql.Timestamp;
import java.util.Date;

//publisher and subscriber act as this
import tcdIO.*;

/**
 *
 *  Subscriber1 class
 * 
 * An instance accepts user input 
 *
 */
public class Subscriber1 extends Node implements Runnable {
	static final int DEST_PORT = 11222;			//broker port
	static final int DEFAULT_SRC_SEND_PORT = 11220;	//send topic to broker
	static final int DEFAULT_SRC_REC_PORT = 11320;	//receive from broker
	static final String DEFAULT_DST_NODE = "localhost";
	

	static final int PACKETSIZE = 65536;	//size of packet
	
	
	
	Terminal terminal;
	InetSocketAddress dstAddress;	//address to construct packet to send
	
	/**
	 * Constructor
	 * 	 
	 * Attempts to create socket at given port and create an InetSocketAddress for the destinations
	 */

	Subscriber1(Terminal terminal, String dstHost, int dstPort, int srcPort) {
		try {
			this.terminal= terminal;
			dstAddress= new InetSocketAddress(dstHost, dstPort);
			socket= new DatagramSocket(srcPort);
			listener.go();
			
			
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	
	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public synchronized void onReceipt(DatagramPacket packet) {
		byte[] buffer;
		
		try {
			// attempt to receive packet
			terminal.println("Subscriber1 trying to receive");
			// create buffer for data, packet and socket
			buffer= new byte[PACKETSIZE+3];
			// extract data from packet
			buffer= packet.getData();
			ByteArrayInputStream bstreamIn = new ByteArrayInputStream(buffer);
			ObjectInputStream ostreamIn = new ObjectInputStream(bstreamIn);

			terminal.println("Subscriber1 received topic : " + ostreamIn.readUTF() + " message: " +ostreamIn.readUTF() );		

		}
		catch(Exception e) {
			System.out.println("subsriber receive error " + e.getMessage());
		}
	}


	/**
	 * Sender Method
	 * 
	 */
	public synchronized void start() throws Exception {
		while(true) {
			inputTopic();
		}
	}


	private void inputTopic() throws IOException {
		// TODO Auto-generated method stub
		ObjectOutputStream ostream;
		ByteArrayOutputStream bstream;
		byte[] buffer;

		DatagramPacket packet= null;
		terminal.println("Subscriber1 sending packet");
		
		bstream= new ByteArrayOutputStream();
		ostream= new ObjectOutputStream(bstream);
		
	   

		String inputTopic = (terminal.readString("Topic to send: "));
		
		Date date= new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		
		ostream.writeUTF("S-"+DEFAULT_SRC_REC_PORT+"_"+ts);
		ostream.writeUTF(inputTopic.toLowerCase());
		ostream.flush();
		buffer= bstream.toByteArray();

		// create packet addressed to destination
		packet= new DatagramPacket(buffer, buffer.length, dstAddress);

		// create socket and send packet
		socket= new DatagramSocket();
		socket.send(packet);
		terminal.println("Subscriber1 sent topic : '" + inputTopic.toLowerCase() + "' sucessfully");
	}


	/**
	 * Test method
	 * 
	 * Sends a packet to a given address
	 */
	public static void main(String[] args) {
		try {					
			Terminal terminal= new Terminal("Subscriber1");	
			(new Thread(new Subscriber1(terminal, DEFAULT_DST_NODE, DEST_PORT, DEFAULT_SRC_REC_PORT))).start();
			(new Subscriber1(terminal, DEFAULT_DST_NODE, DEST_PORT, DEFAULT_SRC_SEND_PORT)).start();
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}


	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Hello from a subscriber receive thread!");
			while(true) {
				this.wait();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
